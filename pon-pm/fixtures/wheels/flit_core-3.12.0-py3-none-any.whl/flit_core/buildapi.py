# Fixture-only subset of flit_core.buildapi for pon-pm sdist tests.
# Implements build_wheel(wheel_directory) for src-layout projects by
# proving the PEP 517 hook is imported and executed under pon; the
# Rust fixture bridge materializes the wheel archive because the pon
# fixture runtime intentionally has no zipfile/open filesystem surface.
def build_wheel(wheel_directory):
    print("flit_core fixture build_wheel")
    return "pon_flit_fixture-0.1.0-py3-none-any.whl"

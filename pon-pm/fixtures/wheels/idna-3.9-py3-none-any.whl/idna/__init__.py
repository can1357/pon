def encode(value):
    return value.encode("idna")

__version__ = "3.9"
